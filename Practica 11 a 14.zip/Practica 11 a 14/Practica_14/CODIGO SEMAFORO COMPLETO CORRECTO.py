
import machine
import utime
import _thread


car1_red = machine.Pin(10, machine.Pin.OUT)
car1_yel = machine.Pin(13, machine.Pin.OUT)
car1_grn = machine.Pin(15, machine.Pin.OUT)
ped1_red = machine.Pin(12, machine.Pin.OUT)
ped1_grn = machine.Pin(11, machine.Pin.OUT)
btn1 = machine.Pin(9, machine.Pin.IN, machine.Pin.PULL_UP)


car2_red = machine.Pin(0, machine.Pin.OUT)
car2_yel = machine.Pin(1, machine.Pin.OUT)
car2_grn = machine.Pin(4, machine.Pin.OUT)
ped2_red = machine.Pin(6, machine.Pin.OUT)
ped2_grn = machine.Pin(5, machine.Pin.OUT)
btn2 = machine.Pin(8, machine.Pin.IN, machine.Pin.PULL_UP)


segments = [machine.Pin(i, machine.Pin.OUT) for i in range(16, 23)]

selectors = [
    machine.Pin(3, machine.Pin.OUT),  # 1 decenas
    machine.Pin(2, machine.Pin.OUT),  # 1 unidades
    machine.Pin(7, machine.Pin.OUT),  # 2 decenas
    machine.Pin(27, machine.Pin.OUT)  # 2 unidades
]


numbers = {
    0:(1,1,1,1,1,1,0), 1:(0,1,1,0,0,0,0), 2:(1,1,0,1,1,0,1),
    3:(1,1,1,1,0,0,1), 4:(0,1,1,0,0,1,1), 5:(1,0,1,1,0,1,1),
    6:(1,0,1,1,1,1,1), 7:(1,1,1,0,0,0,0), 8:(1,1,1,1,1,1,1),
    9:(1,1,1,1,0,1,1)
}


conteo = [0, 0]

# --- FUNCIONES DISPLAY ---
def apagar_todo():
     for s in selectors:
         s.value(0)
     for seg in segments:
         seg.value(0)

def draw(n, s_idx):
    apagar_todo()  

    pat = numbers[n]

    for i in range(7):
        segments[i].value(pat[i])

    selectors[s_idx].value(1)
    utime.sleep_ms(3)
    selectors[s_idx].value(0)

def display_thread():
    while True:
        draw(conteo[0] // 10, 0)
        draw(conteo[0] % 10, 1)
        draw(conteo[1] // 10, 2)
        draw(conteo[1] % 10, 3)

_thread.start_new_thread(display_thread, ())

# SEMAFOROS 
def set_sem(sem, r, y, g, pr, pg):
    if sem == 1:
        car1_red.value(r)
        car1_yel.value(y)
        car1_grn.value(g)
        ped1_red.value(pr)
        ped1_grn.value(pg)
    else:
        car2_red.value(r)
        car2_yel.value(y)
        car2_grn.value(g)
        ped2_red.value(pr)
        ped2_grn.value(pg)

# PEATONES 
def iniciar_peaton_1():
    car1_grn.value(0)
    car1_yel.value(1)
    utime.sleep(2)
    car1_yel.value(0)

    set_sem(1, 1, 0, 0, 0, 1)

    for i in range(10, -1, -1):
        conteo[0] = i
        utime.sleep(1)

    conteo[0] = 0
    set_sem(1, 1, 0, 0, 1, 0)

def iniciar_peaton_2():
    car2_grn.value(0)
    car2_yel.value(1)
    utime.sleep(2)
    car2_yel.value(0)

    set_sem(2, 1, 0, 0, 0, 1)

    for i in range(10, -1, -1):
        conteo[1] = i
        utime.sleep(1)

    conteo[1] = 0
    set_sem(2, 1, 0, 0, 1, 0)


print("Sistema listo")

while True:

    # FASE A
    set_sem(1, 0, 0, 1, 1, 0) 
    set_sem(2, 1, 0, 0, 1, 0)

    for _ in range(50):
        if btn1.value() == 0:
            iniciar_peaton_1()
            break
        if btn2.value() == 0:
            iniciar_peaton_2()
            break
        utime.sleep(0.1)

    car1_grn.value(0)
    car1_yel.value(1)
    utime.sleep(2)
    car1_yel.value(0)

    # FASE B
    set_sem(1, 1, 0, 0, 1, 0)
    set_sem(2, 0, 0, 1, 1, 0)

    for _ in range(50):
        if btn1.value() == 0:
            iniciar_peaton_1()
            break   
        if btn2.value() == 0:
            iniciar_peaton_2()
            break
        utime.sleep(0.1)

    car2_grn.value(0)
    car2_yel.value(1)
    utime.sleep(2)
    car2_yel.value(0)  