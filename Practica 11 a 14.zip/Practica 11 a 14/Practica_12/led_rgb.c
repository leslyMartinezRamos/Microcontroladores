#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/adc.h"
#include "hardware/pwm.h"

// Pines PWM
#define LED_R 15
#define LED_G 14
#define LED_B 13

// Pines ADC
#define POT_R 26
#define POT_G 27
#define POT_B 28

void setup_pwm(uint pin) {
    gpio_set_function(pin, GPIO_FUNC_PWM);
    uint slice = pwm_gpio_to_slice_num(pin);
    pwm_set_wrap(slice, 65535);
    pwm_set_enabled(slice, true);
}

int main() {
    stdio_init_all();

    // Inicializar ADC
    adc_init();
    adc_gpio_init(POT_R);
    adc_gpio_init(POT_G);
    adc_gpio_init(POT_B);

    // Inicializar PWM
    setup_pwm(LED_R);
    setup_pwm(LED_G);
    setup_pwm(LED_B);

    while (true) {

        // Leer ADC (0-4095)
        adc_select_input(0);
        uint16_t val_r = adc_read();

        adc_select_input(1);
        uint16_t val_g = adc_read();

        adc_select_input(2);
        uint16_t val_b = adc_read();

        // Escalar a 16 bits (0-65535)
        val_r <<= 4;
        val_g <<= 4;
        val_b <<= 4;

        //  IMPORTANTE: invertir PWM (ánodo común)
        pwm_set_gpio_level(LED_R, 65535 - val_r);
        pwm_set_gpio_level(LED_G, 65535 - val_g);
        pwm_set_gpio_level(LED_B, 65535 - val_b);

        // Convertir a porcentaje (visual, no invertido)
        int pr = (val_r * 100) / 65535;
        int pg = (val_g * 100) / 65535;
        int pb = (val_b * 100) / 65535;

        // Mostrar en monitor serial
        printf("R: %d%% | G: %d%% | B: %d%%\n", pr, pg, pb);

        sleep_ms(100);
    }
}