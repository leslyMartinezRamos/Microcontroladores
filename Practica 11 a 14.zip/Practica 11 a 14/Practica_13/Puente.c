from machine import Pin, PWM, UART
import time

# UART (USB serial)
uart = UART(0, baudrate=9600)

# Pines del puente H
Q1 = PWM(Pin(0))
Q2 = PWM(Pin(1))
Q3 = PWM(Pin(2))
Q4 = PWM(Pin(3))

# Frecuencia PWM
for pwm in [Q1, Q2, Q3, Q4]:
    pwm.freq(1000)

def detener():
    Q1.duty_u16(0)
    Q2.duty_u16(0)
    Q3.duty_u16(0)
    Q4.duty_u16(0)

def adelante(vel):
    Q1.duty_u16(vel)
    Q4.duty_u16(vel)
    Q2.duty_u16(0)
    Q3.duty_u16(0)

def atras(vel):
    Q2.duty_u16(vel)
    Q3.duty_u16(vel)
    Q1.duty_u16(0)
    Q4.duty_u16(0)

while True:
    if uart.any():
        try:
            data = uart.readline().decode().strip()
            velocidad, direccion = data.split(",")

            velocidad = int(velocidad)
            direccion = int(direccion)

            pwm_val = int((velocidad / 100) * 65535)

            if direccion == 1:
                adelante(pwm_val)
            else:
                atras(pwm_val)

        except:
            detener()