import serial
import matplotlib.pyplot as plt
import time

# Cambia el puerto (COM3, COM4, etc.)
ser = serial.Serial('COM3', 115200)

temperaturas = []
tiempos = []

inicio = time.time()

plt.ion()  # modo interactivo

while True:
    linea = ser.readline().decode().strip()

    if "Temperatura" in linea:
        temp = float(linea.split()[1])

        temperaturas.append(temp)
        tiempos.append(time.time() - inicio)

        plt.clf()
        plt.plot(tiempos, temperaturas)
        plt.xlabel("Tiempo (s)")
        plt.ylabel("Temperatura (°C)")
        plt.title("Temperatura vs Tiempo")
        plt.pause(0.1)